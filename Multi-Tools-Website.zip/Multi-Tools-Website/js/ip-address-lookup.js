document.addEventListener('DOMContentLoaded', function () {
    const lookupBtn = document.getElementById('lookup-btn');
    const ipInput = document.getElementById('ip-input');
    const resultDiv = document.getElementById('result');

    lookupBtn.addEventListener('click', () => {
        const ipAddress = ipInput.value.trim();
        const apiUrl = `http://ip-api.com/json/${ipAddress}`;

        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    resultDiv.innerHTML = `
                        <p><strong>IP Address:</strong> ${data.query}</p>
                        <p><strong>Country:</strong> ${data.country}</p>
                        <p><strong>Region:</strong> ${data.regionName}</p>
                        <p><strong>City:</strong> ${data.city}</p>
                        <p><strong>ISP:</strong> ${data.isp}</p>
                    `;
                } else {
                    resultDiv.innerHTML = `<p class="text-danger">Error: ${data.message}</p>`;
                }
            })
            .catch(error => {
                resultDiv.innerHTML = `<p class="text-danger">An error occurred: ${error}</p>`;
            });
    });
});
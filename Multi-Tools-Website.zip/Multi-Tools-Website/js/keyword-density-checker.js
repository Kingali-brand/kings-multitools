document.addEventListener('DOMContentLoaded', function () {
    const checkBtn = document.getElementById('check-btn');
    const textInput = document.getElementById('text-input');
    const keywordInput = document.getElementById('keyword-input');
    const resultDiv = document.getElementById('result');

    checkBtn.addEventListener('click', () => {
        const text = textInput.value.toLowerCase();
        const keyword = keywordInput.value.toLowerCase();

        if (!text || !keyword) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter both text and a keyword.</p>';
            return;
        }

        const words = text.match(/\b\w+\b/g);
        if (!words) {
            resultDiv.innerHTML = '<p class="text-danger">No words found in the text.</p>';
            return;
        }

        let keywordCount = 0;
        words.forEach(word => {
            if (word === keyword) {
                keywordCount++;
            }
        });

        const totalWords = words.length;
        const density = (keywordCount / totalWords) * 100;

        resultDiv.innerHTML = `
            <p><strong>Keyword:</strong> ${keyword}</p>
            <p><strong>Occurrences:</strong> ${keywordCount}</p>
            <p><strong>Total Words:</strong> ${totalWords}</p>
            <p><strong>Density:</strong> ${density.toFixed(2)}%</p>
        `;
    });
});
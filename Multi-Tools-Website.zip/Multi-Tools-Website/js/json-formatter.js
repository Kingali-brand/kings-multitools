document.addEventListener('DOMContentLoaded', function () {
    const formatBtn = document.getElementById('format-btn');
    const jsonInput = document.getElementById('json-input');
    const resultDiv = document.getElementById('result');

    formatBtn.addEventListener('click', () => {
        try {
            const jsonObj = JSON.parse(jsonInput.value);
            const formattedJson = JSON.stringify(jsonObj, null, 4);
            resultDiv.innerHTML = `<pre><code>${formattedJson}</code></pre>`;
        } catch (e) {
            resultDiv.innerHTML = `<p class="text-danger">Invalid JSON: ${e.message}</p>`;
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const flipBtn = document.getElementById('flip-btn');
    const resultDiv = document.getElementById('result');

    flipBtn.addEventListener('click', () => {
        const randomNumber = Math.random();
        let result = '';
        if (randomNumber < 0.5) {
            result = 'Heads';
        } else {
            result = 'Tails';
        }
        resultDiv.innerHTML = `<p><strong>Result:</strong> ${result}</p>`;
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const calculateBtn = document.getElementById('calculate-btn');
    const percentageInput = document.getElementById('percentage');
    const numberInput = document.getElementById('number');
    const resultDiv = document.getElementById('result');

    calculateBtn.addEventListener('click', () => {
        const percentage = parseFloat(percentageInput.value);
        const number = parseFloat(numberInput.value);

        if (isNaN(percentage) || isNaN(number)) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid numbers.</p>';
            return;
        }

        const result = (percentage / 100) * number;
        resultDiv.innerHTML = `<p><strong>Result:</strong> ${result}</p>`;
    });
});
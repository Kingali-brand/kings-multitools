document.addEventListener('DOMContentLoaded', function () {
    const speakBtn = document.getElementById('speak-btn');
    const textInput = document.getElementById('text-input');
    const resultDiv = document.getElementById('result');

    if ('speechSynthesis' in window) {
        speakBtn.addEventListener('click', () => {
            const text = textInput.value;
            const utterance = new SpeechSynthesisUtterance(text);
            window.speechSynthesis.speak(utterance);
            resultDiv.innerHTML = '<p class="text-success">Speaking...</p>';
        });
    } else {
        resultDiv.innerHTML = '<p class="text-danger">Text-to-Speech not supported in this browser.</p>';
        speakBtn.disabled = true;
    }
});
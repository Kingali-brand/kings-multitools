document.addEventListener('DOMContentLoaded', function () {
    const addItemBtn = document.getElementById('add-item');
    const itemEntriesDiv = document.getElementById('item-entries');
    let itemCount = 1;

    function calculateTotals() {
        let subtotal = 0;
        for (let i = 1; i <= itemCount; i++) {
            const quantityInput = document.getElementById(`item-quantity-${i}`);
            const priceInput = document.getElementById(`item-price-${i}`);
            const itemTotalInput = document.getElementById(`item-total-${i}`);

            const quantity = parseFloat(quantityInput.value);
            const price = parseFloat(priceInput.value);

            if (!isNaN(quantity) && !isNaN(price)) {
                const itemTotal = quantity * price;
                itemTotalInput.value = itemTotal.toFixed(2);
                subtotal += itemTotal;
            } else {
                itemTotalInput.value = '0.00';
            }
        }
        document.getElementById('subtotal').textContent = subtotal.toFixed(2);

        const taxPercentage = parseFloat(document.getElementById('tax-percentage').value);
        const taxAmount = (subtotal * taxPercentage) / 100;
        const grandTotal = subtotal + taxAmount;
        document.getElementById('grand-total').textContent = grandTotal.toFixed(2);
    }

    addItemBtn.addEventListener('click', () => {
        itemCount++;
        const newItemEntry = `
            <div class="item-entry row mb-3 border p-3 rounded">
                <div class="col-md-4">
                    <label for="item-description-${itemCount}" class="form-label">Description</label>
                    <input type="text" id="item-description-${itemCount}" class="form-control">
                </div>
                <div class="col-md-2">
                    <label for="item-quantity-${itemCount}" class="form-label">Quantity</label>
                    <input type="number" id="item-quantity-${itemCount}" class="form-control" value="1">
                </div>
                <div class="col-md-3">
                    <label for="item-price-${itemCount}" class="form-label">Unit Price</label>
                    <input type="number" id="item-price-${itemCount}" class="form-control" step="0.01">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Total</label>
                    <input type="text" id="item-total-${itemCount}" class="form-control" readonly>
                </div>
            </div>
        `;
        itemEntriesDiv.insertAdjacentHTML('beforeend', newItemEntry);
        // Add event listeners to new inputs
        document.getElementById(`item-quantity-${itemCount}`).addEventListener('input', calculateTotals);
        document.getElementById(`item-price-${itemCount}`).addEventListener('input', calculateTotals);
    });

    document.getElementById('tax-percentage').addEventListener('input', calculateTotals);
    document.getElementById('item-quantity-1').addEventListener('input', calculateTotals);
    document.getElementById('item-price-1').addEventListener('input', calculateTotals);

    const generateBtn = document.getElementById('generate-btn');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const invoiceNumber = document.getElementById('invoice-number').value;
        const invoiceDate = document.getElementById('invoice-date').value;
        const dueDate = document.getElementById('due-date').value;
        const billFrom = document.getElementById('bill-from').value.replace(/\n/g, '<br>');
        const billTo = document.getElementById('bill-to').value.replace(/\n/g, '<br>');
        const subtotal = document.getElementById('subtotal').textContent;
        const taxPercentage = document.getElementById('tax-percentage').value;
        const grandTotal = document.getElementById('grand-total').textContent;

        let itemsHtml = '';
        for (let i = 1; i <= itemCount; i++) {
            const description = document.getElementById(`item-description-${i}`).value;
            const quantity = document.getElementById(`item-quantity-${i}`).value;
            const price = document.getElementById(`item-price-${i}`).value;
            const total = document.getElementById(`item-total-${i}`).value;
            if (description && quantity && price) {
                itemsHtml += `
                    <tr>
                        <td>${description}</td>
                        <td>${quantity}</td>
                        <td>${price}</td>
                        <td>${total}</td>
                    </tr>
                `;
            }
        }

        const invoiceHtml = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Invoice #${invoiceNumber}</title>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }
                    .invoice-box { max-width: 800px; margin: auto; padding: 30px; border: 1px solid #eee; box-shadow: 0 0 10px rgba(0, 0, 0, .15); font-size: 16px; line-height: 24px; color: #555; }
                    .invoice-box table { width: 100%; line-height: inherit; text-align: left; border-collapse: collapse; }
                    .invoice-box table td { padding: 5px; vertical-align: top; }
                    .invoice-box table tr td:nth-child(2) { text-align: right; }
                    .invoice-box table tr.top table td { padding-bottom: 20px; }
                    .invoice-box table tr.top table td.title { font-size: 45px; line-height: 45px; color: #333; }
                    .invoice-box table tr.information table td { padding-bottom: 40px; }
                    .invoice-box table tr.heading td { background: #eee; border-bottom: 1px solid #ddd; font-weight: bold; }
                    .invoice-box table tr.details td { padding-bottom: 20px; }
                    .invoice-box table tr.item td { border-bottom: 1px solid #eee; }
                    .invoice-box table tr.item.last td { border-bottom: none; }
                    .invoice-box table tr.total td:nth-child(2) { border-top: 2px solid #eee; font-weight: bold; }
                </style>
            </head>
            <body>
                <div class="invoice-box">
                    <table>
                        <tr class="top">
                            <td colspan="4">
                                <table>
                                    <tr>
                                        <td class="title">
                                            Invoice
                                        </td>
                                        <td>
                                            Invoice #: ${invoiceNumber}<br>
                                            Created: ${invoiceDate}<br>
                                            Due: ${dueDate}
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <tr class="information">
                            <td colspan="4">
                                <table>
                                    <tr>
                                        <td>
                                            ${billFrom}
                                        </td>
                                        <td>
                                            ${billTo}
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <tr class="heading">
                            <td>Item</td>
                            <td>Quantity</td>
                            <td>Unit Price</td>
                            <td>Price</td>
                        </tr>

                        ${itemsHtml}

                        <tr class="total">
                            <td></td>
                            <td></td>
                            <td>Subtotal:</td>
                            <td>${subtotal}</td>
                        </tr>
                        <tr class="total">
                            <td></td>
                            <td></td>
                            <td>Tax (${taxPercentage}%):</td>
                            <td>${(parseFloat(grandTotal) - parseFloat(subtotal)).toFixed(2)}</td>
                        </tr>
                        <tr class="total">
                            <td></td>
                            <td></td>
                            <td>Total:</td>
                            <td>${grandTotal}</td>
                        </tr>
                    </table>
                </div>
            </body>
            </html>
        `;

        resultDiv.innerHTML = `
            <p><strong>Generated Invoice:</strong></p>
            <textarea class="form-control" rows="20" readonly>${invoiceHtml}</textarea>
            <a href="data:text/html;charset=utf-8,${encodeURIComponent(invoiceHtml)}" download="invoice-${invoiceNumber}.html" class="btn btn-success mt-3">Download Invoice (HTML)</a>
        `;
    });

    // Initial calculation
    calculateTotals();
});
document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const fromValueInput = document.getElementById('from-value');
    const fromUnitSelect = document.getElementById('from-unit');
    const toValueInput = document.getElementById('to-value');
    const toUnitSelect = document.getElementById('to-unit');

    const conversionFactors = {
        'm/s': 1,
        'km/h': 0.277778,
        'mph': 0.44704,
        'ft/s': 0.3048,
    };

    convertBtn.addEventListener('click', () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            toValueInput.value = 'Invalid input';
            return;
        }

        const valueInMetersPerSecond = fromValue * conversionFactors[fromUnit];
        const convertedValue = valueInMetersPerSecond / conversionFactors[toUnit];

        toValueInput.value = convertedValue;
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const htmlInput = document.getElementById('html-input');
    const resultDiv = document.getElementById('result');

    convertBtn.addEventListener('click', () => {
        const html = htmlInput.value;
        const turndownService = new TurndownService();
        const markdown = turndownService.turndown(html);
        resultDiv.innerHTML = `<p><strong>Converted Markdown:</strong></p><textarea class="form-control" rows="10" readonly>${markdown}</textarea>`;
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const fromCurrencySelect = document.getElementById('from-currency');
    const toCurrencySelect = document.getElementById('to-currency');
    const amountInput = document.getElementById('amount');
    const convertBtn = document.getElementById('convert-btn');
    const resultDiv = document.getElementById('result');

    const apiKey = 'AIzaSyAcYFjjXfnYyFdmB_Mxb23gFuvXXlDswME'; // Replace with your API key
    const apiUrl = `https://v6.exchangerate-api.com/v6/${apiKey}/latest/USD`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const currencies = Object.keys(data.conversion_rates);
            currencies.forEach(currency => {
                fromCurrencySelect.innerHTML += `<option value="${currency}">${currency}</option>`;
                toCurrencySelect.innerHTML += `<option value="${currency}">${currency}</option>`;
            });
            fromCurrencySelect.value = 'USD';
            toCurrencySelect.value = 'EUR';
        });

    convertBtn.addEventListener('click', () => {
        const amount = parseFloat(amountInput.value);
        const fromCurrency = fromCurrencySelect.value;
        const toCurrency = toCurrencySelect.value;

        if (isNaN(amount)) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid amount.</p>';
            return;
        }

        fetch(`https://v6.exchangerate-api.com/v6/${apiKey}/pair/${fromCurrency}/${toCurrency}/${amount}`)
            .then(response => response.json())
            .then(data => {
                const result = data.conversion_result;
                resultDiv.innerHTML = `<p><strong>${amount} ${fromCurrency} = ${result} ${toCurrency}</strong></p>`;
            });
    });
});
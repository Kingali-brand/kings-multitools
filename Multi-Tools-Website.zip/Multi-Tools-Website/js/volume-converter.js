document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const fromValueInput = document.getElementById('from-value');
    const fromUnitSelect = document.getElementById('from-unit');
    const toValueInput = document.getElementById('to-value');
    const toUnitSelect = document.getElementById('to-unit');

    // Conversion factors to cubic meters (base unit)
    const conversionFactors = {
        cubic_meter: 1,
        liter: 0.001,
        milliliter: 0.000001,
        gallon_us: 0.00378541,
        quart_us: 0.000946353,
        pint_us: 0.000473176,
        cup_us: 0.000236588,
        fluid_ounce_us: 0.0000295735,
    };

    convertBtn.addEventListener('click', () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            toValueInput.value = 'Invalid input';
            return;
        }

        const valueInCubicMeters = fromValue * conversionFactors[fromUnit];
        const convertedValue = valueInCubicMeters / conversionFactors[toUnit];

        toValueInput.value = convertedValue.toFixed(6);
    });
});
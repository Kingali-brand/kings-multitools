document.addEventListener('DOMContentLoaded', function () {
    const encodeBtn = document.getElementById('encode-btn');
    const decodeBtn = document.getElementById('decode-btn');
    const urlInput = document.getElementById('url-input');
    const resultDiv = document.getElementById('result');

    encodeBtn.addEventListener('click', () => {
        const encodedUrl = encodeURIComponent(urlInput.value);
        resultDiv.innerHTML = `<p><strong>Encoded URL:</strong> ${encodedUrl}</p>`;
    });

    decodeBtn.addEventListener('click', () => {
        try {
            const decodedUrl = decodeURIComponent(urlInput.value);
            resultDiv.innerHTML = `<p><strong>Decoded URL:</strong> ${decodedUrl}</p>`;
        } catch (e) {
            resultDiv.innerHTML = `<p class="text-danger">Invalid URL: ${e.message}</p>`;
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const fromTimezoneSelect = document.getElementById('from-timezone');
    const toTimezoneSelect = document.getElementById('to-timezone');
    const fromTimeInput = document.getElementById('from-time');
    const toTimeInput = document.getElementById('to-time');
    const convertBtn = document.getElementById('convert-btn');

    const timezones = moment.tz.names();

    timezones.forEach(tz => {
        fromTimezoneSelect.innerHTML += `<option value="${tz}">${tz}</option>`;
        toTimezoneSelect.innerHTML += `<option value="${tz}">${tz}</option>`;
    });

    fromTimezoneSelect.value = moment.tz.guess();
    toTimezoneSelect.value = 'UTC';

    convertBtn.addEventListener('click', () => {
        const fromTime = fromTimeInput.value;
        const fromTimezone = fromTimezoneSelect.value;
        const toTimezone = toTimezoneSelect.value;

        if (!fromTime) {
            toTimeInput.value = 'Please select a date and time';
            return;
        }

        const fromMoment = moment.tz(fromTime, fromTimezone);
        const toMoment = fromMoment.clone().tz(toTimezone);

        toTimeInput.value = toMoment.format('YYYY-MM-DD HH:mm:ss');
    });
});
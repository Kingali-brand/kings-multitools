document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const textInput = document.getElementById('text-input');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const text = textInput.value;
        const hash = CryptoJS.SHA256(text).toString();
        resultDiv.innerHTML = `<p><strong>SHA256 Hash:</strong> ${hash}</p>`;
    });
});
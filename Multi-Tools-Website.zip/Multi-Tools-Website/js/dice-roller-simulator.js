document.addEventListener('DOMContentLoaded', function () {
    const rollBtn = document.getElementById('roll-btn');
    const numDiceInput = document.getElementById('num-dice');
    const resultDiv = document.getElementById('result');

    rollBtn.addEventListener('click', () => {
        const numDice = parseInt(numDiceInput.value);

        if (isNaN(numDice) || numDice < 1) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid number of dice (at least 1).</p>';
            return;
        }

        let results = [];
        for (let i = 0; i < numDice; i++) {
            results.push(Math.floor(Math.random() * 6) + 1);
        }

        resultDiv.innerHTML = `<p><strong>Roll Results:</strong> ${results.join(', ')}</p>`;
    });
});
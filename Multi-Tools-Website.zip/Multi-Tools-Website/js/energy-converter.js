document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const fromValueInput = document.getElementById('from-value');
    const fromUnitSelect = document.getElementById('from-unit');
    const toValueInput = document.getElementById('to-value');
    const toUnitSelect = document.getElementById('to-unit');

    const conversionFactors = {
        joule: 1,
        kilojoule: 1000,
        calorie: 4.184,
        kilocalorie: 4184,
        wh: 3600,
        kwh: 3600000,
    };

    convertBtn.addEventListener('click', () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            toValueInput.value = 'Invalid input';
            return;
        }

        const valueInJoules = fromValue * conversionFactors[fromUnit];
        const convertedValue = valueInJoules / conversionFactors[toUnit];

        toValueInput.value = convertedValue;
    });
});
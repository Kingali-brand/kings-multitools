document.addEventListener('DOMContentLoaded', function () {
    const textInput = document.getElementById('text-input');
    const upperBtn = document.getElementById('upper-btn');
    const lowerBtn = document.getElementById('lower-btn');
    const sentenceBtn = document.getElementById('sentence-btn');
    const capitalizedBtn = document.getElementById('capitalized-btn');

    upperBtn.addEventListener('click', () => {
        textInput.value = textInput.value.toUpperCase();
    });

    lowerBtn.addEventListener('click', () => {
        textInput.value = textInput.value.toLowerCase();
    });

    sentenceBtn.addEventListener('click', () => {
        const text = textInput.value.toLowerCase();
        textInput.value = text.replace(/(^\s*\w|[.!?]\s*\w)/g, function(c) {
            return c.toUpperCase();
        });
    });

    capitalizedBtn.addEventListener('click', () => {
        const text = textInput.value.toLowerCase();
        textInput.value = text.replace(/\b\w/g, function(c) {
            return c.toUpperCase();
        });
    });
});
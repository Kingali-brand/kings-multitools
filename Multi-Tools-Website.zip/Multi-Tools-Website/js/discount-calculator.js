document.addEventListener('DOMContentLoaded', function () {
    const calculateBtn = document.getElementById('calculate-btn');
    const originalPriceInput = document.getElementById('original-price');
    const discountPercentageInput = document.getElementById('discount-percentage');
    const resultDiv = document.getElementById('result');

    calculateBtn.addEventListener('click', () => {
        const originalPrice = parseFloat(originalPriceInput.value);
        const discountPercentage = parseFloat(discountPercentageInput.value);

        if (isNaN(originalPrice) || isNaN(discountPercentage)) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid numbers.</p>';
            return;
        }

        const discountAmount = (originalPrice * discountPercentage) / 100;
        const finalPrice = originalPrice - discountAmount;

        resultDiv.innerHTML = `
            <p><strong>Discount Amount:</strong> ${discountAmount.toFixed(2)}</p>
            <p><strong>Final Price:</strong> ${finalPrice.toFixed(2)}</p>
        `;
    });
});
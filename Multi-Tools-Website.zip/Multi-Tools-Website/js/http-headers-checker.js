document.addEventListener('DOMContentLoaded', function () {
    const checkBtn = document.getElementById('check-btn');
    const urlInput = document.getElementById('url-input');
    const resultDiv = document.getElementById('result');

    checkBtn.addEventListener('click', () => {
        const url = urlInput.value.trim();

        if (!url) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a URL.</p>';
            return;
        }

        resultDiv.innerHTML = `
            <p class="text-warning">Checking HTTP headers for: <strong>${url}</strong></p>
            <p class="text-info"><strong>Note:</strong> Directly checking HTTP headers from client-side JavaScript is not feasible due to browser security policies (CORS) and the need for server-side interaction to fetch headers from external domains.</p>
            <p>You would need a backend server to perform the HTTP header lookup and then return the results to the frontend.</p>
        `;
    });
});
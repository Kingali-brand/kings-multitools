document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const urlsInput = document.getElementById('urls');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const urls = urlsInput.value.split('\n').map(url => url.trim()).filter(url => url !== '');

        if (urls.length === 0) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter at least one URL.</p>';
            return;
        }

        let sitemapXml = '<?xml version="1.0" encoding="UTF-8"?>\n';
        sitemapXml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

        urls.forEach(url => {
            sitemapXml += '  <url>\n';
            sitemapXml += `    <loc>${url}</loc>\n`;
            sitemapXml += '  </url>\n';
        });

        sitemapXml += '</urlset>';

        resultDiv.innerHTML = `
            <p><strong>Generated Sitemap XML:</strong></p>
            <textarea class="form-control" rows="10" readonly>${sitemapXml}</textarea>
            <a href="data:text/xml;charset=utf-8,${encodeURIComponent(sitemapXml)}" download="sitemap.xml" class="btn btn-success mt-3">Download Sitemap.xml</a>
        `;
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const barcodeDataInput = document.getElementById('barcode-data');
    const barcodeTypeSelect = document.getElementById('barcode-type');
    const barcodeSvg = document.getElementById('barcode-svg');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const barcodeData = barcodeDataInput.value.trim();
        const barcodeType = barcodeTypeSelect.value;

        if (!barcodeData) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter data for the barcode.</p>';
            return;
        }

        try {
            JsBarcode(barcodeSvg, barcodeData, {
                format: barcodeType,
                displayValue: true,
                height: 100,
                width: 2,
            });
            resultDiv.innerHTML = ''; // Clear previous messages
        } catch (e) {
            resultDiv.innerHTML = `<p class="text-danger">Error generating barcode: ${e.message}</p>`;
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const fromValueInput = document.getElementById('from-value');
    const fromUnitSelect = document.getElementById('from-unit');
    const toValueInput = document.getElementById('to-value');
    const toUnitSelect = document.getElementById('to-unit');

    convertBtn.addEventListener('click', () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            toValueInput.value = 'Invalid input';
            return;
        }

        let valueInCelsius;

        if (fromUnit === 'c') {
            valueInCelsius = fromValue;
        } else if (fromUnit === 'f') {
            valueInCelsius = (fromValue - 32) * 5 / 9;
        } else if (fromUnit === 'k') {
            valueInCelsius = fromValue - 273.15;
        }

        let convertedValue;

        if (toUnit === 'c') {
            convertedValue = valueInCelsius;
        } else if (toUnit === 'f') {
            convertedValue = (valueInCelsius * 9 / 5) + 32;
        } else if (toUnit === 'k') {
            convertedValue = valueInCelsius + 273.15;
        }

        toValueInput.value = convertedValue;
    });
});
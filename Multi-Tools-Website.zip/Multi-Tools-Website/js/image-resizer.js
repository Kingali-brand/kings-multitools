document.addEventListener('DOMContentLoaded', function () {
    const imageInput = document.getElementById('image-input');
    const widthInput = document.getElementById('width');
    const heightInput = document.getElementById('height');
    const resizeBtn = document.getElementById('resize-btn');
    const resultDiv = document.getElementById('result');

    resizeBtn.addEventListener('click', () => {
        const file = imageInput.files[0];
        const newWidth = parseInt(widthInput.value);
        const newHeight = parseInt(heightInput.value);

        if (!file) {
            resultDiv.innerHTML = '<p class="text-danger">Please select an image file.</p>';
            return;
        }

        if (isNaN(newWidth) || isNaN(newHeight) || newWidth <= 0 || newHeight <= 0) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid width and height.</p>';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement('canvas');
                canvas.width = newWidth;
                canvas.height = newHeight;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, newWidth, newHeight);
                const resizedImageUrl = canvas.toDataURL(file.type);
                resultDiv.innerHTML = `
                    <p><strong>Resized Image:</strong></p>
                    <img src="${resizedImageUrl}" class="img-fluid mt-3" alt="Resized Image">
                    <a href="${resizedImageUrl}" download="resized-image.${file.type.split('/')[1]}" class="btn btn-success mt-3">Download Resized Image</a>
                `;
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
});
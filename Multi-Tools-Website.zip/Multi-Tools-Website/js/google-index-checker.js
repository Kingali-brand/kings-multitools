document.addEventListener('DOMContentLoaded', function () {
    const checkBtn = document.getElementById('check-btn');
    const urlInput = document.getElementById('url-input');
    const resultDiv = document.getElementById('result');

    checkBtn.addEventListener('click', () => {
        const url = urlInput.value.trim();

        if (!url) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a URL.</p>';
            return;
        }

        resultDiv.innerHTML = `
            <p class="text-warning">Checking Google Index status for: <strong>${url}</strong></p>
            <p class="text-info"><strong>Note:</strong> Directly checking Google Index status from client-side JavaScript is not feasible due to browser security policies (CORS) and the need for server-side API interaction or scraping. This tool would require a backend server to function correctly.</p>
            <p>You would typically use Google Search Console API or a third-party SEO API for this functionality.</p>
        `;
    });
});
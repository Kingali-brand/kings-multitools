document.addEventListener('DOMContentLoaded', function () {
    const checkBtn = document.getElementById('check-btn');
    const urlInput = document.getElementById('url-input');
    const resultDiv = document.getElementById('result');

    checkBtn.addEventListener('click', () => {
        const url = urlInput.value.trim();

        if (!url) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a URL.</p>';
            return;
        }

        resultDiv.innerHTML = `
            <p class="text-warning">Checking page speed for: <strong>${url}</strong></p>
            <p class="text-info"><strong>Note:</strong> Directly checking page speed from client-side JavaScript is not feasible. This functionality typically relies on external APIs (e.g., Google PageSpeed Insights API) that require authentication and server-side processing.</p>
            <p>You would need a backend server to interact with such APIs and then return the results to the frontend.</p>
        `;
    });
});
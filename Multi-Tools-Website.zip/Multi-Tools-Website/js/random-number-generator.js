document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const minInput = document.getElementById('min');
    const maxInput = document.getElementById('max');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const min = parseInt(minInput.value);
        const max = parseInt(maxInput.value);

        if (isNaN(min) || isNaN(max)) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid numbers.</p>';
            return;
        }

        const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
        resultDiv.innerHTML = `<p><strong>Random Number:</strong> ${randomNumber}</p>`;
    });
});
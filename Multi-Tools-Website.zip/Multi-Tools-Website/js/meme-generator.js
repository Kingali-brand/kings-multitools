document.addEventListener('DOMContentLoaded', function () {
    const imageInput = document.getElementById('image-input');
    const topTextInput = document.getElementById('top-text');
    const bottomTextInput = document.getElementById('bottom-text');
    const generateBtn = document.getElementById('generate-btn');
    const memeCanvas = document.getElementById('meme-canvas');
    const ctx = memeCanvas.getContext('2d');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const file = imageInput.files[0];
        const topText = topTextInput.value;
        const bottomText = bottomTextInput.value;

        if (!file) {
            resultDiv.innerHTML = '<p class="text-danger">Please select an image file.</p>';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                memeCanvas.width = img.width;
                memeCanvas.height = img.height;

                ctx.clearRect(0, 0, memeCanvas.width, memeCanvas.height);
                ctx.drawImage(img, 0, 0);

                ctx.font = 'bold 40px Impact';
                ctx.fillStyle = 'white';
                ctx.strokeStyle = 'black';
                ctx.lineWidth = 3;
                ctx.textAlign = 'center';

                // Top text
                ctx.fillText(topText.toUpperCase(), memeCanvas.width / 2, 50);
                ctx.strokeText(topText.toUpperCase(), memeCanvas.width / 2, 50);

                // Bottom text
                ctx.fillText(bottomText.toUpperCase(), memeCanvas.width / 2, memeCanvas.height - 20);
                ctx.strokeText(bottomText.toUpperCase(), memeCanvas.width / 2, memeCanvas.height - 20);

                const memeImageUrl = memeCanvas.toDataURL('image/png');
                resultDiv.innerHTML = `
                    <p><strong>Generated Meme:</strong></p>
                    <a href="${memeImageUrl}" download="meme.png" class="btn btn-success mt-3">Download Meme</a>
                `;
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
});
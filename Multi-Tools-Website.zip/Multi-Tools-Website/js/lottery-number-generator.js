document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const numBallsInput = document.getElementById('num-balls');
    const maxNumberInput = document.getElementById('max-number');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const numBalls = parseInt(numBallsInput.value);
        const maxNumber = parseInt(maxNumberInput.value);

        if (isNaN(numBalls) || isNaN(maxNumber) || numBalls < 1 || maxNumber < 1 || numBalls > maxNumber) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid numbers. Number of balls cannot exceed the maximum number.</p>';
            return;
        }

        const generatedNumbers = new Set();
        while (generatedNumbers.size < numBalls) {
            const randomNumber = Math.floor(Math.random() * maxNumber) + 1;
            generatedNumbers.add(randomNumber);
        }

        const sortedNumbers = Array.from(generatedNumbers).sort((a, b) => a - b);
        resultDiv.innerHTML = `<p><strong>Generated Lottery Numbers:</strong> ${sortedNumbers.join(', ')}</p>`;
    });
});
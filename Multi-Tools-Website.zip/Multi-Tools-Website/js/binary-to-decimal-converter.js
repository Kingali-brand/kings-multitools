document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const binaryInput = document.getElementById('binary-input');
    const resultDiv = document.getElementById('result');

    convertBtn.addEventListener('click', () => {
        const binaryString = binaryInput.value.trim();

        if (!/^[01]+$/.test(binaryString)) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid binary number (only 0s and 1s).</p>';
            return;
        }

        const decimalValue = parseInt(binaryString, 2);
        resultDiv.innerHTML = `<p><strong>Decimal Value:</strong> ${decimalValue}</p>`;
    });
});
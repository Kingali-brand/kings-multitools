document.addEventListener('DOMContentLoaded', function () {
    const formatBtn = document.getElementById('format-btn');
    const sqlInput = document.getElementById('sql-input');
    const resultDiv = document.getElementById('result');

    formatBtn.addEventListener('click', () => {
        const sql = sqlInput.value;
        let formattedSql = sql.replace(/\s+from\s+/gi, '\nFROM ');
        formattedSql = formattedSql.replace(/\s+where\s+/gi, '\nWHERE ');
        formattedSql = formattedSql.replace(/\s+select\s+/gi, '\nSELECT ');
        formattedSql = formattedSql.replace(/\s+insert\s+into\s+/gi, '\nINSERT INTO ');
        formattedSql = formattedSql.replace(/\s+values\s+/gi, '\nVALUES ');
        formattedSql = formattedSql.replace(/\s+update\s+/gi, '\nUPDATE ');
        formattedSql = formattedSql.replace(/\s+set\s+/gi, '\nSET ');
        formattedSql = formattedSql.replace(/\s+delete\s+from\s+/gi, '\nDELETE FROM ');
        formattedSql = formattedSql.replace(/\s+group\s+by\s+/gi, '\nGROUP BY ');
        formattedSql = formattedSql.replace(/\s+order\s+by\s+/gi, '\nORDER BY ');
        formattedSql = formattedSql.replace(/\s+limit\s+/gi, '\nLIMIT ');
        formattedSql = formattedSql.replace(/\s+join\s+/gi, '\nJOIN ');
        formattedSql = formattedSql.replace(/\s+on\s+/gi, '\nON ');
        formattedSql = formattedSql.replace(/\s+and\s+/gi, ' AND ');
        formattedSql = formattedSql.replace(/\s+or\s+/gi, ' OR ');
        formattedSql = formattedSql.replace(/,/g, ',\n    ');

        resultDiv.innerHTML = `<p><strong>Formatted SQL:</strong></p><textarea class="form-control" rows="10" readonly>${formattedSql}</textarea>`;
        resultDiv.innerHTML += '<p class="text-info mt-2"><strong>Note:</strong> This is a basic SQL formatter. For advanced formatting and syntax highlighting, a dedicated library or tool would be more suitable.</p>';
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const fromValueInput = document.getElementById('from-value');
    const fromUnitSelect = document.getElementById('from-unit');
    const toValueInput = document.getElementById('to-value');
    const toUnitSelect = document.getElementById('to-unit');

    // Conversion factors to L/100km (liters per 100 kilometers)
    const toLitersPer100Km = {
        'mpg_us': (value) => 235.215 / value, // 1 MPG (US) = 235.215 L/100km
        'mpg_uk': (value) => 282.481 / value, // 1 MPG (UK) = 282.481 L/100km
        'km_l': (value) => 100 / value,      // 1 km/L = 100 / (km/L) L/100km
        'l_100km': (value) => value,
    };

    // Conversion factors from L/100km
    const fromLitersPer100Km = {
        'mpg_us': (value) => 235.215 / value,
        'mpg_uk': (value) => 282.481 / value,
        'km_l': (value) => 100 / value,
        'l_100km': (value) => value,
    };

    convertBtn.addEventListener('click', () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue) || fromValue <= 0) {
            toValueInput.value = 'Invalid input';
            return;
        }

        // Convert the input value to L/100km
        const valueInLitersPer100Km = toLitersPer100Km[fromUnit](fromValue);

        // Convert from L/100km to the target unit
        const convertedValue = fromLitersPer100Km[toUnit](valueInLitersPer100Km);

        toValueInput.value = convertedValue.toFixed(2);
    });
});
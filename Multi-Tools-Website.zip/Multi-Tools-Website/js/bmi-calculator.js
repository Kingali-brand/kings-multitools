document.addEventListener('DOMContentLoaded', function () {
    const calculateBtn = document.getElementById('calculate-btn');
    const weightInput = document.getElementById('weight');
    const heightInput = document.getElementById('height');
    const resultDiv = document.getElementById('result');

    calculateBtn.addEventListener('click', () => {
        const weight = parseFloat(weightInput.value);
        const height = parseFloat(heightInput.value);

        if (isNaN(weight) || isNaN(height) || height === 0) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid weight and height.</p>';
            return;
        }

        const bmi = (weight / ((height / 100) * (height / 100))).toFixed(2);
        let category = '';

        if (bmi < 18.5) {
            category = 'Underweight';
        } else if (bmi >= 18.5 && bmi <= 24.9) {
            category = 'Normal weight';
        } else if (bmi >= 25 && bmi <= 29.9) {
            category = 'Overweight';
        } else {
            category = 'Obesity';
        }

        resultDiv.innerHTML = `<p><strong>Your BMI:</strong> ${bmi}</p><p><strong>Category:</strong> ${category}</p>`;
    });
});
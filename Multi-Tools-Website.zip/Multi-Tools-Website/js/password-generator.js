document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const lengthInput = document.getElementById('length');
    const includeUppercaseInput = document.getElementById('include-uppercase');
    const includeNumbersInput = document.getElementById('include-numbers');
    const includeSymbolsInput = document.getElementById('include-symbols');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const length = parseInt(lengthInput.value);
        const includeUppercase = includeUppercaseInput.checked;
        const includeNumbers = includeNumbersInput.checked;
        const includeSymbols = includeSymbolsInput.checked;

        const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
        const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numberChars = '0123456789';
        const symbolChars = '!@#$%^&*()_+-=[]{}\\'
';|:<>?,./';

        let chars = lowercaseChars;
        if (includeUppercase) {
            chars += uppercaseChars;
        }
        if (includeNumbers) {
            chars += numberChars;
        }
        if (includeSymbols) {
            chars += symbolChars;
        }

        let password = '';
        for (let i = 0; i < length; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }

        resultDiv.innerHTML = `<p><strong>Generated Password:</strong> ${password}</p>`;
    });
});
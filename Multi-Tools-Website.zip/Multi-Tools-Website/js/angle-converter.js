document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const fromValueInput = document.getElementById('from-value');
    const fromUnitSelect = document.getElementById('from-unit');
    const toValueInput = document.getElementById('to-value');
    const toUnitSelect = document.getElementById('to-unit');

    const conversionFactors = {
        degrees: 1, // Base unit for conversion
        radians: 180 / Math.PI,
        gradians: 0.9,
    };

    convertBtn.addEventListener('click', () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            toValueInput.value = 'Invalid input';
            return;
        }

        // Convert the input value to degrees (base unit)
        let valueInDegrees;
        if (fromUnit === 'degrees') {
            valueInDegrees = fromValue;
        } else if (fromUnit === 'radians') {
            valueInDegrees = fromValue * (180 / Math.PI);
        } else if (fromUnit === 'gradians') {
            valueInDegrees = fromValue * 0.9;
        }

        // Convert from degrees to the target unit
        let convertedValue;
        if (toUnit === 'degrees') {
            convertedValue = valueInDegrees;
        } else if (toUnit === 'radians') {
            convertedValue = valueInDegrees * (Math.PI / 180);
        } else if (toUnit === 'gradians') {
            convertedValue = valueInDegrees / 0.9;
        }

        toValueInput.value = convertedValue.toFixed(4);
    });
});
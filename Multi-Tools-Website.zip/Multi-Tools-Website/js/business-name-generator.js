document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const keywordsInput = document.getElementById('keywords');
    const numNamesInput = document.getElementById('num-names');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const keywords = keywordsInput.value.split(',').map(kw => kw.trim()).filter(kw => kw !== '');
        const numNames = parseInt(numNamesInput.value);

        if (keywords.length === 0) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter at least one keyword.</p>';
            return;
        }

        if (isNaN(numNames) || numNames < 1) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid number of names to generate (at least 1).</p>';
            return;
        }

        const generatedNames = new Set();
        const maxAttempts = numNames * 10; // Prevent infinite loops for impossible combinations
        let attempts = 0;

        while (generatedNames.size < numNames && attempts < maxAttempts) {
            let name = '';
            const numWords = Math.floor(Math.random() * 2) + 1; // 1 or 2 words

            for (let i = 0; i < numWords; i++) {
                const randomKeyword = keywords[Math.floor(Math.random() * keywords.length)];
                name += randomKeyword.charAt(0).toUpperCase() + randomKeyword.slice(1);
            }

            // Add some common suffixes/prefixes
            const suffixes = ["ly", "ify", "fy", "co", "inc", "solutions", "tech", "hub", "lab"];
            if (Math.random() > 0.5 && name.length > 3) { // Randomly add suffix
                name += suffixes[Math.floor(Math.random() * suffixes.length)];
            }

            if (name.length > 2) { // Ensure name is not too short
                generatedNames.add(name);
            }
            attempts++;
        }

        if (generatedNames.size > 0) {
            let namesHtml = '<h5>Generated Business Names:</h5><ul>';
            generatedNames.forEach(name => {
                namesHtml += `<li>${name}</li>`;
            });
            namesHtml += '</ul>';
            resultDiv.innerHTML = namesHtml;
        } else {
            resultDiv.innerHTML = '<p class="text-info">Could not generate names with the given keywords. Try different keywords.</p>';
        }
    });
});
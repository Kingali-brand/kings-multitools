document.addEventListener('DOMContentLoaded', function () {
    const shortenBtn = document.getElementById('shorten-btn');
    const longUrlInput = document.getElementById('long-url-input');
    const resultDiv = document.getElementById('result');

    shortenBtn.addEventListener('click', () => {
        const longUrl = longUrlInput.value.trim();

        if (!longUrl) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a URL to shorten.</p>';
            return;
        }

        fetch(`https://api.shrtco.de/v2/shorten?url=${longUrl}`)
            .then(response => response.json())
            .then(data => {
                if (data.ok) {
                    resultDiv.innerHTML = `
                        <p><strong>Shortened URL:</strong> <a href="${data.result.full_short_link}" target="_blank">${data.result.full_short_link}</a></p>
                    `;
                } else {
                    resultDiv.innerHTML = `<p class="text-danger">Error: ${data.error}</p>`;
                }
            })
            .catch(error => {
                resultDiv.innerHTML = `<p class="text-danger">An error occurred: ${error}</p>`;
            });
    });
});
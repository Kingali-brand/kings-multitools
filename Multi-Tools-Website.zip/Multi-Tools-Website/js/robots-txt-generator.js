document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const userAgentInput = document.getElementById('user-agent');
    const disallowInput = document.getElementById('disallow');
    const allowInput = document.getElementById('allow');
    const sitemapInput = document.getElementById('sitemap');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const userAgent = userAgentInput.value.trim();
        const disallowPaths = disallowInput.value.split('\n').map(path => path.trim()).filter(path => path !== '');
        const allowPaths = allowInput.value.split('\n').map(path => path.trim()).filter(path => path !== '');
        const sitemapUrl = sitemapInput.value.trim();

        let robotsTxtContent = '';

        if (userAgent) {
            robotsTxtContent += `User-agent: ${userAgent}\n`;
        }

        disallowPaths.forEach(path => {
            robotsTxtContent += `Disallow: ${path}\n`;
        });

        allowPaths.forEach(path => {
            robotsTxtContent += `Allow: ${path}\n`;
        });

        if (sitemapUrl) {
            robotsTxtContent += `Sitemap: ${sitemapUrl}\n`;
        }

        if (robotsTxtContent) {
            resultDiv.innerHTML = `
                <p><strong>Generated Robots.txt:</strong></p>
                <textarea class="form-control" rows="10" readonly>${robotsTxtContent}</textarea>
                <a href="data:text/plain;charset=utf-8,${encodeURIComponent(robotsTxtContent)}" download="robots.txt" class="btn btn-success mt-3">Download Robots.txt</a>
            `;
        } else {
            resultDiv.innerHTML = '<p class="text-danger">Please fill in at least one field to generate robots.txt.</p>';
        }
    });
});
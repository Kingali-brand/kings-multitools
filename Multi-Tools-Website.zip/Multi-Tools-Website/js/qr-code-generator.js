document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const textInput = document.getElementById('text-input');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const text = textInput.value;
        resultDiv.innerHTML = '';
        new QRCode(resultDiv, text);
    });
});

document.addEventListener("DOMContentLoaded", function() {
    // Load header
    fetch('header.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('header').innerHTML = data;
            // Search functionality after header is loaded
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.addEventListener('keyup', filterTools);
            }
        });

    // Load footer
    fetch('footer.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('footer').innerHTML = data;
        });

    const tools = [
        {
            "title": "Word Counter",
            "description": "Count the number of words and characters in a text.",
            "link": "tools/word-counter.html",
            "category": "Text Tools"
        },
        {
            "title": "Character Counter",
            "description": "Count the number of characters in a text.",
            "link": "tools/character-counter.html",
            "category": "Text Tools"
        },
        {
            "title": "Text-to-Speech",
            "description": "Convert text into spoken words.",
            "link": "tools/text-to-speech.html",
            "category": "Text Tools"
        },
        {
            "title": "Random Text Generator",
            "description": "Generate random Lorem Ipsum text.",
            "link": "tools/random-text-generator.html",
            "category": "Text Tools"
        },
        {
            "title": "Case Converter",
            "description": "Convert text to uppercase, lowercase, sentence case, or capitalized case.",
            "link": "tools/case-converter.html",
            "category": "Text Tools"
        },
        {
            "title": "Image to PNG Converter",
            "description": "Convert any image to PNG format.",
            "link": "tools/image-to-png.html",
            "category": "Image Tools"
        },
        {
            "title": "Image to JPG Converter",
            "description": "Convert any image to JPG format.",
            "link": "tools/image-to-jpg.html",
            "category": "Image Tools"
        },
        {
            "title": "Image Resizer",
            "description": "Resize images to custom dimensions.",
            "link": "tools/image-resizer.html",
            "category": "Image Tools"
        },
        {
            "title": "Image Compressor",
            "description": "Compress images to reduce file size.",
            "link": "tools/image-compressor.html",
            "category": "Image Tools"
        },
        {
            "title": "Convert Image to Base64",
            "description": "Convert an image file to a Base64 string.",
            "link": "tools/image-to-base64.html",
            "category": "Image Tools"
        },
        {
            "title": "Convert WebP to PNG",
            "description": "Convert WebP images to PNG format.",
            "link": "tools/webp-to-png.html",
            "category": "Image Tools"
        },
        {
            "title": "GIF Maker",
            "description": "Create animated GIFs from multiple images.",
            "link": "tools/gif-maker.html",
            "category": "Image Tools"
        },
        {
            "title": "Meta Tag Generator",
            "description": "Generate essential meta tags for SEO.",
            "link": "tools/meta-tag-generator.html",
            "category": "SEO Tools"
        },
        {
            "title": "Keyword Density Checker",
            "description": "Check the density of keywords in your content.",
            "link": "tools/keyword-density-checker.html",
            "category": "SEO Tools"
        },
        {
            "title": "Sitemap Generator",
            "description": "Generate an XML sitemap for your website.",
            "link": "tools/sitemap-generator.html",
            "category": "SEO Tools"
        },
        {
            "title": "Robots.txt Generator",
            "description": "Generate a robots.txt file for your website.",
            "link": "tools/robots-txt-generator.html",
            "category": "SEO Tools"
        },
        {
            "title": "Google Index Checker",
            "description": "Check if a URL is indexed by Google (requires backend).",
            "link": "tools/google-index-checker.html",
            "category": "SEO Tools"
        },
        {
            "title": "Domain Authority Checker",
            "description": "Check the domain authority of a website (requires backend).",
            "link": "tools/domain-authority-checker.html",
            "category": "SEO Tools"
        },
        {
            "title": "Backlink Checker",
            "description": "Check the backlinks of a website (requires backend).",
            "link": "tools/backlink-checker.html",
            "category": "SEO Tools"
        },
        {
            "title": "Page Speed Checker",
            "description": "Check the loading speed of a web page (requires backend).",
            "link": "tools/page-speed-checker.html",
            "category": "SEO Tools"
        },
        {
            "title": "XML Sitemap Validator",
            "description": "Validate the structure of an XML sitemap (requires backend).",
            "link": "tools/xml-sitemap-validator.html",
            "category": "SEO Tools"
        },
        {
            "title": "Mobile-Friendly Test",
            "description": "Check if a web page is mobile-friendly (requires backend).",
            "link": "tools/mobile-friendly-test.html",
            "category": "SEO Tools"
        },
        {
            "title": "HTML to Markdown Converter",
            "description": "Convert HTML content to Markdown format.",
            "link": "tools/html-to-markdown.html",
            "category": "Developer Tools"
        },
        {
            "title": "CSS Minifier",
            "description": "Minify CSS code to reduce file size.",
            "link": "tools/css-minifier.html",
            "category": "Developer Tools"
        },
        {
            "title": "JavaScript Minifier",
            "description": "Minify JavaScript code to reduce file size.",
            "link": "tools/javascript-minifier.html",
            "category": "Developer Tools"
        },
        {
            "title": "SQL Formatter",
            "description": "Format and beautify your SQL queries.",
            "link": "tools/sql-formatter.html",
            "category": "Developer Tools"
        },
        {
            "title": "HTACCESS Redirect Generator",
            "description": "Generate .htaccess redirect rules.",
            "link": "tools/htaccess-redirect-generator.html",
            "category": "Developer Tools"
        },
        {
            "title": "Markdown to HTML Converter",
            "description": "Convert Markdown text to HTML.",
            "link": "tools/markdown-to-html.html",
            "category": "Developer Tools"
        },
        {
            "title": "Percentage Calculator",
            "description": "Calculate percentages with ease.",
            "link": "tools/percentage-calculator.html",
            "category": "Math & Calculators"
        },
        {
            "title": "JSON Formatter",
            "description": "Format and beautify your JSON data.",
            "link": "tools/json-formatter.html",
            "category": "Developer Tools"
        },
        {
            "title": "MD5 Hash Generator",
            "description": "Generate MD5 hash of a string.",
            "link": "tools/md5-hash-generator.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "QR Code Generator",
            "description": "Generate a QR code from text.",
            "link": "tools/qr-code-generator.html",
            "category": "Image Tools"
        },
        {
            "title": "Password Generator",
            "description": "Generate a secure, random password.",
            "link": "tools/password-generator.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "Length Converter",
            "description": "Convert between different units of length.",
            "link": "tools/length-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Weight Converter",
            "description": "Convert between different units of weight.",
            "link": "tools/weight-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Temperature Converter",
            "description": "Convert between Celsius, Fahrenheit, and Kelvin.",
            "link": "tools/temperature-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Speed Converter",
            "description": "Convert between different units of speed.",
            "link": "tools/speed-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Time Zone Converter",
            "description": "Convert times between different timezones.",
            "link": "tools/time-zone-converter.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Currency Converter",
            "description": "Convert between different currencies.",
            "link": "tools/currency-converter.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Random Number Generator",
            "description": "Generate a random number within a specified range.",
            "link": "tools/random-number-generator.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "Dice Roller Simulator",
            "description": "Simulate rolling one or more dice.",
            "link": "tools/dice-roller-simulator.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "BMI Calculator",
            "description": "Calculate your Body Mass Index.",
            "link": "tools/bmi-calculator.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Age Calculator",
            "description": "Calculate your age based on your date of birth.",
            "link": "tools/age-calculator.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Discount Calculator",
            "description": "Calculate the final price after a discount.",
            "link": "tools/discount-calculator.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Tip Calculator",
            "description": "Calculate the tip and total bill.",
            "link": "tools/tip-calculator.html",
            "category": "Math & Calculators"
        },
        {
            "title": "URL Encoder & Decoder",
            "description": "Encode or decode URLs.",
            "link": "tools/url-encoder-decoder.html",
            "category": "Text Tools"
        },
        {
            "title": "Base64 Encoder & Decoder",
            "description": "Encode or decode text to/from Base64.",
            "link": "tools/base64-encoder-decoder.html",
            "category": "Developer Tools"
        },
        {
            "title": "Color Code Picker",
            "description": "Pick colors and get their Hex and RGB codes.",
            "link": "tools/color-code-picker.html",
            "category": "Developer Tools"
        },
        {
            "title": "IP Address Lookup",
            "description": "Look up details about an IP address.",
            "link": "tools/ip-address-lookup.html",
            "category": "Developer Tools"
        },
        {
            "title": "Random String Generator",
            "description": "Generate a random string with customizable options.",
            "link": "tools/random-string-generator.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "Scientific Calculator",
            "description": "Perform advanced mathematical calculations.",
            "link": "tools/scientific-calculator.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Loan EMI Calculator",
            "description": "Calculate your Equated Monthly Installment (EMI) for loans.",
            "link": "tools/loan-emi-calculator.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Binary to Decimal Converter",
            "description": "Convert binary numbers to decimal.",
            "link": "tools/binary-to-decimal-converter.html",
            "category": "Math & Calculators"
        },
        {
            "title": "Data Storage Converter",
            "description": "Convert between different units of data storage.",
            "link": "tools/data-storage-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Energy Converter",
            "description": "Convert between different units of energy.",
            "link": "tools/energy-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Pressure Converter",
            "description": "Convert between different units of pressure.",
            "link": "tools/pressure-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Fuel Efficiency Converter",
            "description": "Convert between different units of fuel efficiency.",
            "link": "tools/fuel-efficiency-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Angle Converter",
            "description": "Convert between different units of angle (degrees, radians, gradians).",
            "link": "tools/angle-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "Volume Converter",
            "description": "Convert between different units of volume.",
            "link": "tools/volume-converter.html",
            "category": "Unit Converters"
        },
        {
            "title": "SHA256 Hash Generator",
            "description": "Generate SHA256 hash of a string.",
            "link": "tools/sha256-hash-generator.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "URL Shortener",
            "description": "Shorten long URLs.",
            "link": "tools/url-shortener.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "IP Geolocation Finder",
            "description": "Find the geographical location of an IP address.",
            "link": "tools/ip-geolocation-finder.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "SSL Certificate Checker",
            "description": "Check the validity and details of an SSL certificate (requires backend).",
            "link": "tools/ssl-certificate-checker.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "Whois Lookup",
            "description": "Look up domain registration information (requires backend).",
            "link": "tools/whois-lookup.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "HTTP Headers Checker",
            "description": "Check HTTP headers of a website (requires backend).",
            "link": "tools/http-headers-checker.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "Privacy Policy Generator",
            "description": "Generate a basic privacy policy for your website.",
            "link": "tools/privacy-policy-generator.html",
            "category": "Security & Encryption Tools"
        },
        {
            "title": "Barcode Generator",
            "description": "Generate various types of barcodes.",
            "link": "tools/barcode-generator.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "Meme Generator",
            "description": "Create custom memes with your own images and text.",
            "link": "tools/meme-generator.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "Resume Builder",
            "description": "Build a simple HTML resume.",
            "link": "tools/resume-builder.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "Invoice Generator",
            "description": "Generate simple invoices for your services.",
            "link": "tools/invoice-generator.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "Business Name Generator",
            "description": "Generate creative business names based on keywords.",
            "link": "tools/business-name-generator.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "Lottery Number Generator",
            "description": "Generate random lottery numbers.",
            "link": "tools/lottery-number-generator.html",
            "category": "Miscellaneous Tools"
        },
        {
            "title": "Flip a Coin Simulator",
            "description": "Simulate flipping a coin.",
            "link": "tools/flip-a-coin-simulator.html",
            "category": "Miscellaneous Tools"
        },
        // Add more tools here
    ];

    const toolsGrid = document.getElementById('tools-grid');
    if (toolsGrid) {
        toolsGrid.innerHTML = '';
        tools.forEach(tool => {
            const toolCard = `
                <div class="col-md-4 mb-4 tool-card" data-category="${tool.category}">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">${tool.title}</h5>
                            <p class="card-text">${tool.description}</p>
                            <a href="${tool.link}" class="btn btn-primary">Use Tool</a>
                        </div>
                    </div>
                </div>
            `;
            toolsGrid.innerHTML += toolCard;
        });
    }
});

function filterTools() {
    const searchInput = document.getElementById('searchInput');
    const filter = searchInput.value.toLowerCase();
    const toolCards = document.querySelectorAll('.tool-card');

    toolCards.forEach(card => {
        const title = card.querySelector('.card-title').textContent.toLowerCase();
        const description = card.querySelector('.card-text').textContent.toLowerCase();
        if (title.includes(filter) || description.includes(filter)) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}

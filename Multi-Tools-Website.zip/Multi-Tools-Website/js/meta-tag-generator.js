document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const titleInput = document.getElementById('title');
    const descriptionInput = document.getElementById('description');
    const keywordsInput = document.getElementById('keywords');
    const authorInput = document.getElementById('author');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const title = titleInput.value.trim();
        const description = descriptionInput.value.trim();
        const keywords = keywordsInput.value.trim();
        const author = authorInput.value.trim();

        let metaTags = '';

        if (title) {
            metaTags += `<meta property="og:title" content="${title}">
`;
            metaTags += `<meta name="twitter:title" content="${title}">
`;
        }
        if (description) {
            metaTags += `<meta name="description" content="${description}">
`;
            metaTags += `<meta property="og:description" content="${description}">
`;
            metaTags += `<meta name="twitter:description" content="${description}">
`;
        }
        if (keywords) {
            metaTags += `<meta name="keywords" content="${keywords}">
`;
        }
        if (author) {
            metaTags += `<meta name="author" content="${author}">
`;
        }

        if (metaTags) {
            resultDiv.innerHTML = `
                <p><strong>Generated Meta Tags:</strong></p>
                <textarea class="form-control" rows="10" readonly>${metaTags}</textarea>
            `;
        } else {
            resultDiv.innerHTML = '<p class="text-danger">Please fill in at least one field to generate meta tags.</p>';
        }
    });
});
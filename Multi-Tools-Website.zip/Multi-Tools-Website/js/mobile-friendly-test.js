document.addEventListener('DOMContentLoaded', function () {
    const testBtn = document.getElementById('test-btn');
    const urlInput = document.getElementById('url-input');
    const resultDiv = document.getElementById('result');

    testBtn.addEventListener('click', () => {
        const url = urlInput.value.trim();

        if (!url) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a URL.</p>';
            return;
        }

        resultDiv.innerHTML = `
            <p class="text-warning">Running mobile-friendly test for: <strong>${url}</strong></p>
            <p class="text-info"><strong>Note:</strong> Directly performing a mobile-friendly test from client-side JavaScript is not feasible. This functionality typically relies on external APIs (e.g., Google Mobile-Friendly Test API) that require authentication and server-side processing.</p>
            <p>You would need a backend server to interact with such APIs and then return the results to the frontend.</p>
        `;
    });
});
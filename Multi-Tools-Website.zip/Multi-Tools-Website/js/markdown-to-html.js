document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convert-btn');
    const markdownInput = document.getElementById('markdown-input');
    const resultDiv = document.getElementById('result');

    convertBtn.addEventListener('click', () => {
        const markdown = markdownInput.value;
        const html = marked.parse(markdown);
        resultDiv.innerHTML = `<p><strong>Converted HTML:</strong></p><textarea class="form-control" rows="10" readonly>${html}</textarea>`;
    });
});
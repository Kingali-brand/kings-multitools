document.addEventListener('DOMContentLoaded', function () {
    const imageInput = document.getElementById('image-input');
    const convertBtn = document.getElementById('convert-btn');
    const resultDiv = document.getElementById('result');

    convertBtn.addEventListener('click', () => {
        const file = imageInput.files[0];
        if (!file) {
            resultDiv.innerHTML = '<p class="text-danger">Please select an image file.</p>';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                const pngUrl = canvas.toDataURL('image/png');
                resultDiv.innerHTML = `
                    <p><strong>Conversion Successful!</strong></p>
                    <img src="${pngUrl}" class="img-fluid mt-3" alt="Converted PNG Image">
                    <a href="${pngUrl}" download="converted-image.png" class="btn btn-success mt-3">Download PNG</a>
                `;
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
});
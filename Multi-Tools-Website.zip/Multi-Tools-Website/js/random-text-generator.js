document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const paragraphsInput = document.getElementById('paragraphs');
    const resultDiv = document.getElementById('result');

    const loremIpsumText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

    generateBtn.addEventListener('click', () => {
        const numParagraphs = parseInt(paragraphsInput.value);

        if (isNaN(numParagraphs) || numParagraphs < 1) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid number of paragraphs (at least 1).</p>';
            return;
        }

        let generatedText = '';
        for (let i = 0; i < numParagraphs; i++) {
            generatedText += `<p>${loremIpsumText}</p>`;
        }

        resultDiv.innerHTML = generatedText;
    });
});
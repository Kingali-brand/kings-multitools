document.addEventListener('DOMContentLoaded', function () {
    const imageInput = document.getElementById('image-input');
    const delayInput = document.getElementById('delay');
    const makeGifBtn = document.getElementById('make-gif-btn');
    const resultDiv = document.getElementById('result');

    makeGifBtn.addEventListener('click', () => {
        const files = imageInput.files;
        const delay = parseInt(delayInput.value);

        if (files.length === 0) {
            resultDiv.innerHTML = '<p class="text-danger">Please select image files.</p>';
            return;
        }

        if (isNaN(delay) || delay < 50) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid frame delay (at least 50ms).</p>';
            return;
        }

        resultDiv.innerHTML = '<p>Generating GIF... This may take a moment.</p>';

        const gif = new GIF({
            workers: 2,
            quality: 10,
            width: 200, // Default width, will be adjusted by first image
            height: 200 // Default height, will be adjusted by first image
        });

        let imagesLoaded = 0;
        const imagesToLoad = files.length;

        Array.from(files).forEach(file => {
            const reader = new FileReader();
            reader.onload = function (e) {
                const img = new Image();
                img.onload = function () {
                    if (imagesLoaded === 0) {
                        gif.options.width = img.width;
                        gif.options.height = img.height;
                    }
                    gif.addFrame(img, { delay: delay });
                    imagesLoaded++;
                    if (imagesLoaded === imagesToLoad) {
                        gif.render();
                    }
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        });

        gif.on('finished', function (blob) {
            const gifUrl = URL.createObjectURL(blob);
            resultDiv.innerHTML = `
                <p><strong>GIF Generated!</strong></p>
                <img src="${gifUrl}" class="img-fluid mt-3" alt="Generated GIF">
                <a href="${gifUrl}" download="generated.gif" class="btn btn-success mt-3">Download GIF</a>
            `;
        });

        gif.on('progress', function (p) {
            resultDiv.innerHTML = `<p>Generating GIF... ${Math.round(p * 100)}%</p>`;
        });

        gif.on('error', function (error) {
            resultDiv.innerHTML = `<p class="text-danger">Error generating GIF: ${error}</p>`;
        });
    });
});
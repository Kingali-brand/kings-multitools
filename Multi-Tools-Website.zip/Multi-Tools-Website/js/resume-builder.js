document.addEventListener('DOMContentLoaded', function () {
    const addEducationBtn = document.getElementById('add-education');
    const educationEntriesDiv = document.getElementById('education-entries');
    let educationCount = 1;

    addEducationBtn.addEventListener('click', () => {
        educationCount++;
        const newEducationEntry = `
            <div class="education-entry mb-3 border p-3 rounded">
                <div class="mb-3">
                    <label for="degree-${educationCount}" class="form-label">Degree/Qualification</label>
                    <input type="text" id="degree-${educationCount}" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="university-${educationCount}" class="form-label">University/Institution</label>
                    <input type="text" id="university-${educationCount}" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="edu-years-${educationCount}" class="form-label">Years Attended</label>
                    <input type="text" id="edu-years-${educationCount}" class="form-control" placeholder="e.g., 2018 - 2022">
                </div>
            </div>
        `;
        educationEntriesDiv.insertAdjacentHTML('beforeend', newEducationEntry);
    });

    const addExperienceBtn = document.getElementById('add-experience');
    const experienceEntriesDiv = document.getElementById('experience-entries');
    let experienceCount = 1;

    addExperienceBtn.addEventListener('click', () => {
        experienceCount++;
        const newExperienceEntry = `
            <div class="experience-entry mb-3 border p-3 rounded">
                <div class="mb-3">
                    <label for="job-title-${experienceCount}" class="form-label">Job Title</label>
                    <input type="text" id="job-title-${experienceCount}" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="company-${experienceCount}" class="form-label">Company</label>
                    <input type="text" id="company-${experienceCount}" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="exp-years-${experienceCount}" class="form-label">Years Worked</label>
                    <input type="text" id="exp-years-${experienceCount}" class="form-control" placeholder="e.g., 2022 - Present">
                </div>
                <div class="mb-3">
                    <label for="responsibilities-${experienceCount}" class="form-label">Responsibilities (one per line)</label>
                    <textarea id="responsibilities-${experienceCount}" class="form-control" rows="3"></textarea>
                </div>
            </div>
        `;
        experienceEntriesDiv.insertAdjacentHTML('beforeend', newExperienceEntry);
    });

    const generateBtn = document.getElementById('generate-btn');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const fullName = document.getElementById('full-name').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        const linkedin = document.getElementById('linkedin').value;
        const summary = document.getElementById('summary').value;
        const skills = document.getElementById('skills').value.split(',').map(s => s.trim()).filter(s => s !== '');

        let educationHtml = '';
        for (let i = 1; i <= educationCount; i++) {
            const degree = document.getElementById(`degree-${i}`).value;
            const university = document.getElementById(`university-${i}`).value;
            const eduYears = document.getElementById(`edu-years-${i}`).value;
            if (degree && university && eduYears) {
                educationHtml += `
                    <p><strong>${degree}</strong> from ${university} (${eduYears})</p>
                `;
            }
        }

        let experienceHtml = '';
        for (let i = 1; i <= experienceCount; i++) {
            const jobTitle = document.getElementById(`job-title-${i}`).value;
            const company = document.getElementById(`company-${i}`).value;
            const expYears = document.getElementById(`exp-years-${i}`).value;
            const responsibilities = document.getElementById(`responsibilities-${i}`).value.split('\n').map(r => r.trim()).filter(r => r !== '');
            if (jobTitle && company && expYears) {
                experienceHtml += `
                    <h3>${jobTitle} at ${company} (${expYears})</h3>
                    <ul>
                        ${responsibilities.map(r => `<li>${r}</li>`).join('')}
                    </ul>
                `;
            }
        }

        const resumeHtml = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${fullName} - Resume</title>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .section { margin-bottom: 20px; }
                    .section h2 { border-bottom: 1px solid #ccc; padding-bottom: 5px; margin-bottom: 10px; }
                    ul { list-style-type: disc; margin-left: 20px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>${fullName}</h1>
                    <p>${email} | ${phone} ${linkedin ? `| <a href="${linkedin}" target="_blank">LinkedIn</a>` : ''}</p>
                </div>

                <div class="section">
                    <h2>Summary</h2>
                    <p>${summary}</p>
                </div>

                <div class="section">
                    <h2>Education</h2>
                    ${educationHtml}
                </div>

                <div class="section">
                    <h2>Experience</h2>
                    ${experienceHtml}
                </div>

                <div class="section">
                    <h2>Skills</h2>
                    <p>${skills.join(', ')}</p>
                </div>
            </body>
            </html>
        `;

        resultDiv.innerHTML = `
            <p><strong>Generated Resume:</strong></p>
            <textarea class="form-control" rows="20" readonly>${resumeHtml}</textarea>
            <a href="data:text/html;charset=utf-8,${encodeURIComponent(resumeHtml)}" download="${fullName.replace(/\s/g, '-')}-resume.html" class="btn btn-success mt-3">Download Resume (HTML)</a>
        `;
    });
});
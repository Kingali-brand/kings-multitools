document.addEventListener('DOMContentLoaded', function () {
    const minifyBtn = document.getElementById('minify-btn');
    const cssInput = document.getElementById('css-input');
    const resultDiv = document.getElementById('result');

    minifyBtn.addEventListener('click', () => {
        const css = cssInput.value;
        // Remove comments
        let minifiedCss = css.replace(/\/\*[^*]*\*+(?:[^/*][^*]*\*+)*\//g, '');
        // Remove newlines, tabs, and extra spaces
        minifiedCss = minifiedCss.replace(/\s+/g, ' ');
        minifiedCss = minifiedCss.replace(/\s*([{}|:;,])\s*/g, '$1');
        minifiedCss = minifiedCss.replace(/;}/g, '}');

        resultDiv.innerHTML = `<p><strong>Minified CSS:</strong></p><textarea class="form-control" rows="10" readonly>${minifiedCss}</textarea>`;
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const generateBtn = document.getElementById('generate-btn');
    const oldUrlInput = document.getElementById('old-url');
    const newUrlInput = document.getElementById('new-url');
    const redirectTypeSelect = document.getElementById('redirect-type');
    const resultDiv = document.getElementById('result');

    generateBtn.addEventListener('click', () => {
        const oldUrl = oldUrlInput.value.trim();
        const newUrl = newUrlInput.value.trim();
        const redirectType = redirectTypeSelect.value;

        if (!oldUrl || !newUrl) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter both old and new URLs.</p>';
            return;
        }

        let redirectCode = '';
        if (redirectType === '301') {
            redirectCode = `Redirect 301 ${oldUrl} ${newUrl}`;
        } else if (redirectType === '302') {
            redirectCode = `Redirect 302 ${oldUrl} ${newUrl}`;
        }

        resultDiv.innerHTML = `
            <p><strong>Generated .htaccess Code:</strong></p>
            <textarea class="form-control" rows="5" readonly>${redirectCode}</textarea>
            <p class="text-info mt-2">Add this code to your .htaccess file.</p>
        `;
    });
});
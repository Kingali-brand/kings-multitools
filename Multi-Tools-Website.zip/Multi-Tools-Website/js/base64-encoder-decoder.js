document.addEventListener('DOMContentLoaded', function () {
    const encodeBtn = document.getElementById('encode-btn');
    const decodeBtn = document.getElementById('decode-btn');
    const textInput = document.getElementById('text-input');
    const resultDiv = document.getElementById('result');

    encodeBtn.addEventListener('click', () => {
        const encodedText = btoa(textInput.value);
        resultDiv.innerHTML = `<p><strong>Encoded Base64:</strong> ${encodedText}</p>`;
    });

    decodeBtn.addEventListener('click', () => {
        try {
            const decodedText = atob(textInput.value);
            resultDiv.innerHTML = `<p><strong>Decoded Text:</strong> ${decodedText}</p>`;
        } catch (e) {
            resultDiv.innerHTML = `<p class="text-danger">Invalid Base64 string: ${e.message}</p>`;
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const imageInput = document.getElementById('image-input');
    const qualityInput = document.getElementById('quality');
    const compressBtn = document.getElementById('compress-btn');
    const resultDiv = document.getElementById('result');

    compressBtn.addEventListener('click', () => {
        const file = imageInput.files[0];
        const quality = parseFloat(qualityInput.value);

        if (!file) {
            resultDiv.innerHTML = '<p class="text-danger">Please select an image file.</p>';
            return;
        }

        if (isNaN(quality) || quality < 0.1 || quality > 1.0) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid quality value (0.1 - 1.0).</p>';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);

                // Compress image
                const compressedImageUrl = canvas.toDataURL(file.type, quality);

                resultDiv.innerHTML = `
                    <p><strong>Compressed Image:</strong></p>
                    <img src="${compressedImageUrl}" class="img-fluid mt-3" alt="Compressed Image">
                    <a href="${compressedImageUrl}" download="compressed-image.${file.type.split('/')[1]}" class="btn btn-success mt-3">Download Compressed Image</a>
                `;
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const imageInput = document.getElementById('image-input');
    const convertBtn = document.getElementById('convert-btn');
    const resultDiv = document.getElementById('result');

    convertBtn.addEventListener('click', () => {
        const file = imageInput.files[0];
        if (!file) {
            resultDiv.innerHTML = '<p class="text-danger">Please select an image file.</p>';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const base64String = e.target.result;
            resultDiv.innerHTML = `
                <p><strong>Base64 String:</strong></p>
                <textarea class="form-control" rows="10" readonly>${base64String}</textarea>
                <a href="${base64String}" download="image.txt" class="btn btn-success mt-3">Download Base64 String</a>
            `;
        };
        reader.readAsDataURL(file);
    });
});
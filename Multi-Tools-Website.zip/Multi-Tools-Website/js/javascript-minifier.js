document.addEventListener('DOMContentLoaded', function () {
    const minifyBtn = document.getElementById('minify-btn');
    const jsInput = document.getElementById('js-input');
    const resultDiv = document.getElementById('result');

    minifyBtn.addEventListener('click', () => {
        const jsCode = jsInput.value;
        // Basic minification: remove comments and extra whitespace
        let minifiedJs = jsCode.replace(/\/\/[^\n]*|\/\*[\s\S]*?\*\//g, ''); // Remove single-line and multi-line comments
        minifiedJs = minifiedJs.replace(/\s{2,}/g, ' '); // Replace multiple spaces with a single space
        minifiedJs = minifiedJs.replace(/\n/g, ''); // Remove newlines
        minifiedJs = minifiedJs.replace(/\t/g, ''); // Remove tabs
        minifiedJs = minifiedJs.replace(/\s*([,;{}()=+\-*\/&|!~%<>?:[\]])\s*/g, '$1'); // Remove spaces around operators and punctuation

        resultDiv.innerHTML = `<p><strong>Minified JavaScript:</strong></p><textarea class="form-control" rows="10" readonly>${minifiedJs}</textarea>`;
        resultDiv.innerHTML += '<p class="text-info mt-2"><strong>Note:</strong> This is a basic minifier that removes comments and whitespace. For advanced minification (e.g., variable renaming, dead code elimination), a dedicated JavaScript minification library or tool (like UglifyJS or Terser) would be required, which typically runs server-side or as part of a build process.</p>';
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const checkBtn = document.getElementById('check-btn');
    const domainInput = document.getElementById('domain-input');
    const resultDiv = document.getElementById('result');

    checkBtn.addEventListener('click', () => {
        const domain = domainInput.value.trim();

        if (!domain) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a domain.</p>';
            return;
        }

        resultDiv.innerHTML = `
            <p class="text-warning">Checking SSL certificate for: <strong>${domain}</strong></p>
            <p class="text-info"><strong>Note:</strong> Directly checking SSL certificates from client-side JavaScript is not feasible due to browser security policies (CORS) and the need for server-side interaction to retrieve certificate details.</p>
            <p>You would need a backend server to perform the SSL certificate lookup and then return the results to the frontend.</p>
        `;
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const calculateBtn = document.getElementById('calculate-btn');
    const dobInput = document.getElementById('dob');
    const resultDiv = document.getElementById('result');

    calculateBtn.addEventListener('click', () => {
        const dob = new Date(dobInput.value);
        if (isNaN(dob.getTime())) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter a valid date of birth.</p>';
            return;
        }

        const today = new Date();
        let age = today.getFullYear() - dob.getFullYear();
        const monthDifference = today.getMonth() - dob.getMonth();

        if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < dob.getDate())) {
            age--;
        }

        resultDiv.innerHTML = `<p><strong>Your Age:</strong> ${age} years</p>`;
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const calculateBtn = document.getElementById('calculate-btn');
    const loanAmountInput = document.getElementById('loan-amount');
    const interestRateInput = document.getElementById('interest-rate');
    const loanTenureInput = document.getElementById('loan-tenure');
    const resultDiv = document.getElementById('result');

    calculateBtn.addEventListener('click', () => {
        const loanAmount = parseFloat(loanAmountInput.value);
        const annualInterestRate = parseFloat(interestRateInput.value);
        const loanTenureYears = parseFloat(loanTenureInput.value);

        if (isNaN(loanAmount) || isNaN(annualInterestRate) || isNaN(loanTenureYears) || loanAmount <= 0 || annualInterestRate < 0 || loanTenureYears <= 0) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid positive numbers for all fields.</p>';
            return;
        }

        const monthlyInterestRate = annualInterestRate / (12 * 100);
        const numberOfPayments = loanTenureYears * 12;

        let emi = 0;
        if (monthlyInterestRate === 0) {
            emi = loanAmount / numberOfPayments;
        } else {
            emi = loanAmount * monthlyInterestRate * Math.pow((1 + monthlyInterestRate), numberOfPayments) / (Math.pow((1 + monthlyInterestRate), numberOfPayments) - 1);
        }

        resultDiv.innerHTML = `<p><strong>Monthly EMI:</strong> ${emi.toFixed(2)}</p>`;
    });
});
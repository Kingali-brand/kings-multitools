document.addEventListener('DOMContentLoaded', function () {
    const calculateBtn = document.getElementById('calculate-btn');
    const billAmountInput = document.getElementById('bill-amount');
    const tipPercentageInput = document.getElementById('tip-percentage');
    const resultDiv = document.getElementById('result');

    calculateBtn.addEventListener('click', () => {
        const billAmount = parseFloat(billAmountInput.value);
        const tipPercentage = parseFloat(tipPercentageInput.value);

        if (isNaN(billAmount) || isNaN(tipPercentage)) {
            resultDiv.innerHTML = '<p class="text-danger">Please enter valid numbers.</p>';
            return;
        }

        const tipAmount = (billAmount * tipPercentage) / 100;
        const totalBill = billAmount + tipAmount;

        resultDiv.innerHTML = `
            <p><strong>Tip Amount:</strong> ${tipAmount.toFixed(2)}</p>
            <p><strong>Total Bill:</strong> ${totalBill.toFixed(2)}</p>
        `;
    });
});
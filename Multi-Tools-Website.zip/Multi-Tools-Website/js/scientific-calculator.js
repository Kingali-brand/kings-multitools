document.addEventListener('DOMContentLoaded', function () {
    const output = document.getElementById('output');
    const buttons = document.querySelectorAll('button');
    let currentExpression = '';

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const value = button.dataset.value;
            const clear = button.dataset.clear;
            const del = button.dataset.delete;
            const equals = button.dataset.equals;

            if (clear !== undefined) {
                currentExpression = '';
                output.textContent = '0';
            } else if (del !== undefined) {
                currentExpression = currentExpression.slice(0, -1);
                output.textContent = currentExpression === '' ? '0' : currentExpression;
            } else if (equals !== undefined) {
                try {
                    // Replace custom operators for eval
                    let evalExpression = currentExpression.replace(/÷/g, '/').replace(/×/g, '*');
                    // Handle trigonometric functions
                    evalExpression = evalExpression.replace(/sin\(([^)]+)\)/g, 'Math.sin($1 * Math.PI / 180)');
                    evalExpression = evalExpression.replace(/cos\(([^)]+)\)/g, 'Math.cos($1 * Math.PI / 180)');
                    evalExpression = evalExpression.replace(/tan\(([^)]+)\)/g, 'Math.tan($1 * Math.PI / 180)');

                    const result = eval(evalExpression);
                    output.textContent = result;
                    currentExpression = result.toString();
                } catch (e) {
                    output.textContent = 'Error';
                    currentExpression = '';
                }
            } else {
                currentExpression += value;
                output.textContent = currentExpression;
            }
        });
    });
});
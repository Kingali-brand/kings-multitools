document.addEventListener('DOMContentLoaded', function () {
    const countBtn = document.getElementById('count-btn');
    const textInput = document.getElementById('text-input');
    const resultDiv = document.getElementById('result');

    countBtn.addEventListener('click', () => {
        const text = textInput.value;
        const charCount = text.length;

        resultDiv.innerHTML = `<p><strong>Character Count:</strong> ${charCount}</p>`;
    });
});